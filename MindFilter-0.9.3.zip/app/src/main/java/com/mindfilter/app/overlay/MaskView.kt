package com.mindfilter.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.hypot
import kotlin.math.min

/** Point d'un geste, en coordonnées écran. */
data class TouchPoint(val x: Float, val y: Float, val t: Long)

/** Reçoit en direct les glissements faits sur un masque (pour les relayer à l'appli). */
interface DragRelay {
    fun onDragStart(first: TouchPoint)
    fun onDragMove(p: TouchPoint)
    fun onDragEnd(last: TouchPoint)
}

/**
 * Plaque de « verre dépoli » opaque (le contenu dessous reste illisible) avec une
 * capsule noire « Masqué » au centre. Aucun geste ne permet de révéler le contenu.
 */
@SuppressLint("ViewConstructor")
class MaskView(
    context: Context,
    private var dark: Boolean,
    private val relay: DragRelay,
) : View(context) {

    private val dp = resources.displayMetrics.density
    private val sp = resources.displayMetrics.scaledDensity
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val capsule = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0xFFFFFFFF.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.01f
    }
    private val rect = RectF()
    private val pill = RectF()
    private val eye = Path()

    private val points = ArrayList<TouchPoint>(64)
    private var dragging = false

    init {
        isClickable = false
        isLongClickable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        contentDescription = null
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    /** Style « Couleur » : teinte choisie (0 à 360°), ou null pour les styles clair / sombre. */
    private var hue: Float? = null

    fun setHue(value: Float?) {
        if (value != hue) {
            hue = value
            onSizeChanged(width, height, width, height)
            invalidate()
        }
    }

    /** Style « Verre » fait maison : image très réduite de ce qu'il y a dessous (taches de
     *  couleur), agrandie en douceur. null = pas encore de capture → masque opaque. */
    private var backdrop: android.graphics.Bitmap? = null
    private var fakeGlass = false
    private val backdropPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val clipPath = Path()
    private val dst = RectF()

    fun setFakeGlass(on: Boolean) {
        if (on == fakeGlass) return
        fakeGlass = on
        if (!on) backdrop = null
        onSizeChanged(width, height, width, height)
        invalidate()
    }

    fun setBackdrop(b: android.graphics.Bitmap?) {
        backdrop = b
        onSizeChanged(width, height, width, height)
        invalidate()
    }

    /** Texte affiché à la place de « Masqué » après un appui sur le « i » (catégorie). */
    private var infoText: String? = null
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        typeface = Typeface.create("serif", Typeface.BOLD_ITALIC)
        textAlign = Paint.Align.CENTER
    }
    private val clearInfo = Runnable {
        infoText = null
        invalidate()
    }

    /** Le masque est-il assez grand pour porter le bouton « i » ? */
    fun hasInfoBadge(): Boolean = width >= 140f * dp && height >= 60f * dp

    /** Affiche la catégorie pendant quelques secondes, puis revient à « Masqué ». */
    fun showInfo(text: String) {
        infoText = text
        removeCallbacks(clearInfo)
        postDelayed(clearInfo, 4000)
        invalidate()
    }

    /** Style « Verre » : voile translucide (le flou est fait par la fenêtre derrière). */
    private var glass = false

    fun setGlass(value: Boolean) {
        if (value != glass) {
            glass = value
            onSizeChanged(width, height, width, height)
            invalidate()
        }
    }

    /** Image en cours d'analyse : capsule « Analyse… » au lieu de « Masqué ». */
    private var pending = false

    fun setPending(value: Boolean) {
        if (value != pending) {
            pending = value
            invalidate()
        }
    }

    fun setDark(value: Boolean) {
        if (value != dark) {
            dark = value
            onSizeChanged(width, height, width, height)
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        fill.color = when {
            fakeGlass && backdrop != null && dark -> 0x7318191E
            fakeGlass && backdrop != null -> 0x66F4F6FA
            glass && dark -> 0x6618191E
            glass -> 0x59F4F6FA
            dark -> 0xFF24262D.toInt()
            else -> 0xFFE4E7EE.toInt()
        }
        sheen.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            if (dark) 0x26FFFFFF else 0x8CFFFFFF.toInt(),
            if (dark) 0x05FFFFFF else 0x14FFFFFF,
            Shader.TileMode.CLAMP,
        )
        glow.shader = RadialGradient(
            w * 0.15f, h * 0.05f, maxOf(w, h) * 0.75f,
            if (dark) 0x1FB4C8FF else 0x66FFFFFF,
            0x00FFFFFF,
            Shader.TileMode.CLAMP,
        )
        border.strokeWidth = 1f * dp
        border.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            if (dark) 0x40FFFFFF else 0xE6FFFFFF.toInt(),
            if (dark) 0x0FFFFFFF else 0x59FFFFFF,
            Shader.TileMode.CLAMP,
        )
        hue?.let { hv ->
            // Dégradé en diagonale : teinte claire et lumineuse en haut à gauche, plus profonde
            // (et légèrement décalée) en bas à droite. Toujours opaque.
            val top = android.graphics.Color.HSVToColor(floatArrayOf(hv, 0.55f, 0.95f))
            val bottom = android.graphics.Color.HSVToColor(floatArrayOf((hv + 28f) % 360f, 0.85f, 0.55f))
            fill.color = 0xFF000000.toInt()
            fill.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), top, bottom, Shader.TileMode.CLAMP)
            sheen.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
            border.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0x80FFFFFF.toInt(), 0x14FFFFFF, Shader.TileMode.CLAMP)
        } ?: run { fill.shader = null }
        capsule.color = 0xEB0B0B0D.toInt()
        textPaint.textSize = 13f * sp
        iconPaint.strokeWidth = 1.6f * dp
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val inset = border.strokeWidth / 2f
        rect.set(inset, inset, w - inset, h - inset)
        val radius = min(28f * dp, min(w, h) / 2f)

        // Verre fait maison : taches de couleur de ce qu'il y a dessous, puis voile.
        val bd = backdrop
        if (fakeGlass && bd != null && !bd.isRecycled) {
            clipPath.reset()
            clipPath.addRoundRect(rect, radius, radius, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(clipPath)
            dst.set(0f, 0f, w, h)
            canvas.drawBitmap(bd, null, dst, backdropPaint)
            canvas.restore()
        }
        canvas.drawRoundRect(rect, radius, radius, fill)
        canvas.drawRoundRect(rect, radius, radius, glow)
        canvas.drawRoundRect(rect, radius, radius, sheen)
        canvas.drawRoundRect(rect, radius, radius, border)

        // Petit bouton « i » en bas à droite (s'il y a la place) : le toucher affiche la catégorie.
        if (hasInfoBadge()) {
            val r = 11f * dp
            val bx = w - 20f * dp
            val by = h - 20f * dp
            canvas.drawCircle(bx, by, r, capsule)
            badgeText.textSize = 13f * sp
            val fm = badgeText.fontMetrics
            canvas.drawText("i", bx, by - (fm.ascent + fm.descent) / 2f, badgeText)
        }

        // Capsule centrale
        var label = infoText ?: if (pending) "Analyse…" else "Masqué"
        // Texte d'information trop long pour la largeur du masque : raccourci avec « … ».
        val maxText = w - 16f * dp - 13f * dp * 2 - 24f * dp
        if (infoText != null && maxText > 40f * dp) {
            while (label.length > 4 && textPaint.measureText(label) > maxText) label = label.dropLast(2) + "…"
        }
        val iconW = 18f * dp
        val gap = 6f * dp
        val padH = 13f * dp
        val textW = textPaint.measureText(label)
        val fullW = padH + iconW + gap + textW + padH
        val capH = min(32f * dp, h - 8f * dp)
        if (capH < 18f * dp) return
        val showText = fullW + 16f * dp <= w
        val capW = if (showText) fullW else capH + 8f * dp
        val cx = w / 2f
        val cy = h / 2f
        pill.set(cx - capW / 2f, cy - capH / 2f, cx + capW / 2f, cy + capH / 2f)
        canvas.drawRoundRect(pill, capH / 2f, capH / 2f, capsule)

        val iconCx = if (showText) pill.left + padH + iconW / 2f else cx
        drawEye(canvas, iconCx, cy, iconW)
        if (showText) {
            val fm = textPaint.fontMetrics
            val baseline = cy - (fm.ascent + fm.descent) / 2f
            canvas.drawText(label, pill.left + padH + iconW + gap, baseline, textPaint)
        }
    }

    /** Œil barré, tracé à la main pour rester net à toutes les tailles. */
    private fun drawEye(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        val hw = size / 2f
        val hh = size * 0.32f
        eye.reset()
        eye.moveTo(cx - hw, cy)
        eye.quadTo(cx, cy - hh * 2f, cx + hw, cy)
        eye.quadTo(cx, cy + hh * 2f, cx - hw, cy)
        eye.close()
        canvas.drawPath(eye, iconPaint)
        canvas.drawCircle(cx, cy, size * 0.14f, iconPaint)
        canvas.drawLine(cx - hw * 0.8f, cy - hw * 0.8f, cx + hw * 0.8f, cy + hw * 0.8f, iconPaint)
    }

    /**
     * Tous les appuis sont absorbés (simple, double, long) : rien ne passe à la
     * publication située dessous. Un glissement est transmis au service, qui le rejoue
     * sur l'application pour faire défiler la page.
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                points.clear()
                dragging = false
                points.add(TouchPoint(event.rawX, event.rawY, event.eventTime))
            }
            MotionEvent.ACTION_MOVE -> {
                val batch = ArrayList<TouchPoint>(event.historySize + 1)
                for (i in 0 until event.historySize) {
                    val dx = event.getHistoricalX(i) - event.x
                    val dy = event.getHistoricalY(i) - event.y
                    batch.add(TouchPoint(event.rawX + dx, event.rawY + dy, event.getHistoricalEventTime(i)))
                }
                batch.add(TouchPoint(event.rawX, event.rawY, event.eventTime))
                if (dragging) {
                    batch.forEach { relay.onDragMove(it) }
                } else {
                    points.addAll(batch)
                    val first = points.first()
                    if (hypot(event.rawX - first.x, event.rawY - first.y) > touchSlop) {
                        // Le doigt glisse : à partir de maintenant, tout le mouvement est
                        // relayé en direct à l'application (défilement naturel).
                        dragging = true
                        relay.onDragStart(first)
                        points.drop(1).forEach { relay.onDragMove(it) }
                        points.clear()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) relay.onDragEnd(TouchPoint(event.rawX, event.rawY, event.eventTime))
                // Simple appui, double appui ou appui long : rien n'est transmis.
                points.clear()
                dragging = false
            }
        }
        return true
    }
}
